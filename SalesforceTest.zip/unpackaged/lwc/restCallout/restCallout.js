import { LightningElement,wire } from 'lwc';
import makeGetCallout from '@salesforce/apex/RestAPICall.makeGetCallout';
import createRecords from '@salesforce/apex/RestAPICall.createRecords';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

export default class RestCallout extends LightningElement {
    contactRecord;
    maxRowSelection =1;
    showimportbutton=false;
    selectedRow;
    selectRow = false;
    Name;
    Firstname;
    Lastname;
    Email;
    BirthDate;
    columns = [
        { label: 'Name', fieldName: 'name' },
        { label: 'Email', fieldName: 'email', type: 'email' },
        { label: 'First Name', fieldName: 'firstname', type: 'text' },
        { label: 'Last Name', fieldName: 'lastname', type: 'text' },
        { label: 'Birth Date', fieldName: 'BirthDate', type: 'date' }
    ];


    data =[];
    
    recordId;
    error;

    
@wire (makeGetCallout)
makeGetCallout({error, data}){
    if(data){

        
        this.contactRecord = JSON.parse(JSON.stringify(data));
        
    }
    if(error){
        this.error =error;
            console.log(error);
    }
   
}
    
    getContactsData() {
        this.data = this.contactRecord;
           console.log('contactRecord',this.contactRecord);
            this.showimportbutton =true;
        }

        ViewRecords(event){
            const selectedRow = event.detail.selectedRows;
            this.selectRow = true;
            console.log('selectedRow',selectedRow); 
            this.Name = selectedRow[0].name;
            console.log('selectedRow',this.Name);
            this.Firstname = selectedRow[0].firstname;
            console.log('selectedRow', this.Firstname);
            this.Lastname = selectedRow[0].lastname;
            this.Email = selectedRow[0].email;
            this.BirthDate=selectedRow[0].BirthDate;
        }

        createRecords(){

            if(this.selectRow == false){
                this.showToast('warning','Warning!!','Select one Record to Insert');
                
            }
        else{
           console.log('contactRecord',this.contactRecord.length);
           console.log('contactRecord name',this.contactRecord[0].name);
           let cont = { 'sobjectType': 'ImportContact__c' };      
            cont.Name =  this.Name;
            cont.First_Name__c = this.Firstname;
            cont.Last_Name__c = this.Lastname;
            cont.Email__c = this.Email;
            cont.Birthdate__c = this.BirthDate;
            console.log(cont);
           if(cont.Name!=undefined){
            createRecords({rec: cont})
                .then(result => {
                    this.recordId = result;
                    this.showToast('Success','Success!!','Succesfully Inserted!');
                })
                .catch(error => {
                    console.log(error);
                    this.error = error;
                    this.showToast('error','Error!!','Something went wrong.Please try again later!');
            });  
        }
    }
        }

        showToast(type,msgtitle,msg)
    {
        const evt = new ShowToastEvent({
            title: msgtitle,
            message: msg,
            variant: type,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }
}